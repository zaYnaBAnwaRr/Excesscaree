const mongoose = require('mongoose');

const supportRequestSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
        maxlength: [100, 'Name cannot exceed 100 characters']
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        trim: true,
        lowercase: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
    },
    phone: {
        type: String,
        required: [true, 'Phone is required'],
        trim: true,
        maxlength: [20, 'Phone number cannot exceed 20 characters']
    },
    serviceType: {
        type: String,
        required: [true, 'Service type is required'],
        enum: ['in-home', 'medical', 'companionship', 'transportation', 'other'],
        default: 'in-home'
    },
    urgency: {
        type: String,
        enum: ['low', 'medium', 'high', 'emergency'],
        default: 'medium'
    },
    message: {
        type: String,
        trim: true,
        maxlength: [2000, 'Message cannot exceed 2000 characters']
    },
    status: {
        type: String,
        enum: ['pending', 'in-progress', 'completed', 'cancelled'],
        default: 'pending'
    },
    priority: {
        type: String,
        enum: ['low', 'medium', 'high', 'urgent'],
        default: 'medium'
    },
    assignedTo: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Admin',
        default: null
    },
    estimatedStartDate: {
        type: Date,
        default: null
    },
    estimatedDuration: {
        type: String,
        enum: ['1-3 days', '1 week', '2-4 weeks', '1-3 months', 'ongoing'],
        default: null
    },
    notes: [{
        note: {
            type: String,
            required: true,
            trim: true
        },
        addedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Admin',
            required: true
        },
        addedAt: {
            type: Date,
            default: Date.now
        }
    }],
    response: {
        type: String,
        trim: true,
        maxlength: [2000, 'Response cannot exceed 2000 characters']
    },
    respondedAt: {
        type: Date,
        default: null
    },
    completedAt: {
        type: Date,
        default: null
    }
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Index for better query performance
supportRequestSchema.index({ email: 1 });
supportRequestSchema.index({ status: 1 });
supportRequestSchema.index({ urgency: 1 });
supportRequestSchema.index({ serviceType: 1 });
supportRequestSchema.index({ createdAt: -1 });

// Virtual for formatted phone number
supportRequestSchema.virtual('formattedPhone').get(function() {
    if (!this.phone) return '';
    const cleaned = this.phone.replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
        return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    return this.phone;
});

// Virtual for service type display name
supportRequestSchema.virtual('serviceDisplayName').get(function() {
    const serviceNames = {
        'in-home': 'In-Home Care',
        'medical': 'Medical Support',
        'companionship': 'Companionship',
        'transportation': 'Transportation',
        'other': 'Other'
    };
    return serviceNames[this.serviceType] || this.serviceType;
});

// Pre-save middleware to format phone number and set priority based on urgency
supportRequestSchema.pre('save', function(next) {
    if (this.phone) {
        this.phone = this.phone.replace(/\D/g, '');
    }
    
    // Set priority based on urgency
    if (this.urgency === 'emergency') {
        this.priority = 'urgent';
    } else if (this.urgency === 'high') {
        this.priority = 'high';
    } else if (this.urgency === 'medium') {
        this.priority = 'medium';
    } else {
        this.priority = 'low';
    }
    
    next();
});

// Static method to get support request statistics
supportRequestSchema.statics.getStats = async function() {
    const stats = await this.aggregate([
        {
            $group: {
                _id: '$status',
                count: { $sum: 1 }
            }
        }
    ]);
    
    const urgencyStats = await this.aggregate([
        {
            $group: {
                _id: '$urgency',
                count: { $sum: 1 }
            }
        }
    ]);
    
    const serviceStats = await this.aggregate([
        {
            $group: {
                _id: '$serviceType',
                count: { $sum: 1 }
            }
        }
    ]);
    
    const total = await this.countDocuments();
    const thisMonth = await this.countDocuments({
        createdAt: { $gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) }
    });
    
    return {
        total,
        thisMonth,
        byStatus: stats.reduce((acc, stat) => {
            acc[stat._id] = stat.count;
            return acc;
        }, {}),
        byUrgency: urgencyStats.reduce((acc, stat) => {
            acc[stat._id] = stat.count;
            return acc;
        }, {}),
        byService: serviceStats.reduce((acc, stat) => {
            acc[stat._id] = stat.count;
            return acc;
        }, {})
    };
};

// Method to add a note
supportRequestSchema.methods.addNote = function(note, adminId) {
    this.notes.push({
        note,
        addedBy: adminId,
        addedAt: new Date()
    });
    return this.save();
};

module.exports = mongoose.model('SupportRequest', supportRequestSchema);
