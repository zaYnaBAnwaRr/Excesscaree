const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const Admin = require('../models/Admin');
const Contact = require('../models/Contact');
const SupportRequest = require('../models/SupportRequest');
const router = express.Router();

// Middleware to verify JWT token
const authenticateToken = async (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({
            success: false,
            message: 'Access token required'
        });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
        const admin = await Admin.findById(decoded.id).select('-password');
        
        if (!admin || !admin.isActive) {
            return res.status(401).json({
                success: false,
                message: 'Invalid or inactive admin account'
            });
        }

        req.user = admin;
        next();
    } catch (error) {
        return res.status(403).json({
            success: false,
            message: 'Invalid or expired token'
        });
    }
};

// Validation middleware
const loginValidation = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address'),
    body('password')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters')
];

const adminValidation = [
    body('name')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters'),
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address'),
    body('password')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters'),
    body('role')
        .isIn(['admin', 'super_admin', 'support_agent'])
        .withMessage('Invalid role')
];

// @route   POST /api/admin/login
// @desc    Admin login
// @access  Public
router.post('/login', loginValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { email, password } = req.body;

        // Find admin with password
        const admin = await Admin.findOne({ email }).select('+password');
        
        if (!admin || !admin.isActive) {
            return res.status(401).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        // Check password
        const isMatch = await admin.comparePassword(password);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        // Update last login
        await admin.updateLastLogin();

        // Generate JWT token
        const token = jwt.sign(
            { id: admin._id, email: admin.email, role: admin.role },
            process.env.JWT_SECRET || 'your-secret-key',
            { expiresIn: '24h' }
        );

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                token,
                admin: {
                    id: admin._id,
                    name: admin.name,
                    email: admin.email,
                    role: admin.role,
                    permissions: admin.permissions,
                    lastLogin: admin.lastLogin
                }
            }
        });

    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({
            success: false,
            message: 'Login failed. Please try again later.'
        });
    }
});

// @route   POST /api/admin/register
// @desc    Register new admin (Super admin only)
// @access  Private
router.post('/register', authenticateToken, adminValidation, async (req, res) => {
    try {
        // Check if user has permission to create admins
        if (req.user.role !== 'super_admin' && !req.user.permissions.canManageAdmins) {
            return res.status(403).json({
                success: false,
                message: 'Insufficient permissions'
            });
        }

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { name, email, password, role, permissions } = req.body;

        // Check if admin already exists
        const existingAdmin = await Admin.findOne({ email });
        if (existingAdmin) {
            return res.status(400).json({
                success: false,
                message: 'Admin with this email already exists'
            });
        }

        // Create new admin
        const admin = new Admin({
            name,
            email,
            password,
            role: role || 'support_agent',
            permissions: permissions || {}
        });

        await admin.save();

        res.status(201).json({
            success: true,
            message: 'Admin created successfully',
            data: {
                id: admin._id,
                name: admin.name,
                email: admin.email,
                role: admin.role,
                permissions: admin.permissions
            }
        });

    } catch (error) {
        console.error('Admin registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create admin'
        });
    }
});

// @route   GET /api/admin/profile
// @desc    Get admin profile
// @access  Private
router.get('/profile', authenticateToken, async (req, res) => {
    try {
        res.json({
            success: true,
            data: req.user
        });
    } catch (error) {
        console.error('Get profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch profile'
        });
    }
});

// @route   PUT /api/admin/profile
// @desc    Update admin profile
// @access  Private
router.put('/profile', authenticateToken, async (req, res) => {
    try {
        const { name, profile } = req.body;
        const updateData = {};
        
        if (name) updateData.name = name;
        if (profile) updateData.profile = { ...req.user.profile, ...profile };

        const admin = await Admin.findByIdAndUpdate(
            req.user._id,
            updateData,
            { new: true, runValidators: true }
        ).select('-password');

        res.json({
            success: true,
            message: 'Profile updated successfully',
            data: admin
        });

    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update profile'
        });
    }
});

// @route   GET /api/admin/dashboard
// @desc    Get dashboard statistics
// @access  Private
router.get('/dashboard', authenticateToken, async (req, res) => {
    try {
        const [
            contactStats,
            supportStats,
            adminStats
        ] = await Promise.all([
            Contact.getStats(),
            SupportRequest.getStats(),
            Admin.getStats()
        ]);

        // Recent activities
        const recentContacts = await Contact.find()
            .sort({ createdAt: -1 })
            .limit(5)
            .select('name email status createdAt');

        const recentSupportRequests = await SupportRequest.find()
            .sort({ createdAt: -1 })
            .limit(5)
            .select('name email serviceType urgency status createdAt');

        res.json({
            success: true,
            data: {
                contacts: contactStats,
                supportRequests: supportStats,
                admins: adminStats,
                recentActivities: {
                    contacts: recentContacts,
                    supportRequests: recentSupportRequests
                }
            }
        });

    } catch (error) {
        console.error('Get dashboard error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch dashboard data'
        });
    }
});

// @route   GET /api/admin/admins
// @desc    Get all admins (Super admin only)
// @access  Private
router.get('/admins', authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== 'super_admin' && !req.user.permissions.canManageAdmins) {
            return res.status(403).json({
                success: false,
                message: 'Insufficient permissions'
            });
        }

        const admins = await Admin.find()
            .select('-password')
            .sort({ createdAt: -1 });

        res.json({
            success: true,
            data: admins
        });

    } catch (error) {
        console.error('Get admins error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch admins'
        });
    }
});

// @route   PUT /api/admin/admins/:id
// @desc    Update admin (Super admin only)
// @access  Private
router.put('/admins/:id', authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== 'super_admin' && !req.user.permissions.canManageAdmins) {
            return res.status(403).json({
                success: false,
                message: 'Insufficient permissions'
            });
        }

        const { name, role, isActive, permissions } = req.body;
        const updateData = {};

        if (name) updateData.name = name;
        if (role) updateData.role = role;
        if (typeof isActive === 'boolean') updateData.isActive = isActive;
        if (permissions) updateData.permissions = permissions;

        const admin = await Admin.findByIdAndUpdate(
            req.params.id,
            updateData,
            { new: true, runValidators: true }
        ).select('-password');

        if (!admin) {
            return res.status(404).json({
                success: false,
                message: 'Admin not found'
            });
        }

        res.json({
            success: true,
            message: 'Admin updated successfully',
            data: admin
        });

    } catch (error) {
        console.error('Update admin error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update admin'
        });
    }
});

// @route   DELETE /api/admin/admins/:id
// @desc    Delete admin (Super admin only)
// @access  Private
router.delete('/admins/:id', authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== 'super_admin' && !req.user.permissions.canManageAdmins) {
            return res.status(403).json({
                success: false,
                message: 'Insufficient permissions'
            });
        }

        // Prevent deleting self
        if (req.params.id === req.user._id.toString()) {
            return res.status(400).json({
                success: false,
                message: 'Cannot delete your own account'
            });
        }

        const admin = await Admin.findByIdAndDelete(req.params.id);

        if (!admin) {
            return res.status(404).json({
                success: false,
                message: 'Admin not found'
            });
        }

        res.json({
            success: true,
            message: 'Admin deleted successfully'
        });

    } catch (error) {
        console.error('Delete admin error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete admin'
        });
    }
});

// @route   POST /api/admin/change-password
// @desc    Change admin password
// @access  Private
router.post('/change-password', authenticateToken, async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'Current password and new password are required'
            });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'New password must be at least 6 characters'
            });
        }

        // Get admin with password
        const admin = await Admin.findById(req.user._id).select('+password');

        // Check current password
        const isMatch = await admin.comparePassword(currentPassword);
        if (!isMatch) {
            return res.status(400).json({
                success: false,
                message: 'Current password is incorrect'
            });
        }

        // Update password
        admin.password = newPassword;
        await admin.save();

        res.json({
            success: true,
            message: 'Password changed successfully'
        });

    } catch (error) {
        console.error('Change password error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to change password'
        });
    }
});

module.exports = router;
