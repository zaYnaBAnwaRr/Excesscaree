const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const adminSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
        maxlength: [100, 'Name cannot exceed 100 characters']
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        trim: true,
        lowercase: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [6, 'Password must be at least 6 characters'],
        select: false
    },
    role: {
        type: String,
        enum: ['admin', 'super_admin', 'support_agent'],
        default: 'support_agent'
    },
    isActive: {
        type: Boolean,
        default: true
    },
    lastLogin: {
        type: Date,
        default: null
    },
    profile: {
        phone: {
            type: String,
            trim: true,
            maxlength: [20, 'Phone number cannot exceed 20 characters']
        },
        department: {
            type: String,
            trim: true,
            maxlength: [50, 'Department cannot exceed 50 characters']
        },
        avatar: {
            type: String,
            default: null
        }
    },
    permissions: {
        canViewContacts: {
            type: Boolean,
            default: true
        },
        canEditContacts: {
            type: Boolean,
            default: false
        },
        canViewSupportRequests: {
            type: Boolean,
            default: true
        },
        canEditSupportRequests: {
            type: Boolean,
            default: false
        },
        canAssignRequests: {
            type: Boolean,
            default: false
        },
        canViewAnalytics: {
            type: Boolean,
            default: false
        },
        canManageAdmins: {
            type: Boolean,
            default: false
        }
    }
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Index for better query performance
adminSchema.index({ email: 1 });
adminSchema.index({ role: 1 });
adminSchema.index({ isActive: 1 });

// Virtual for formatted phone number
adminSchema.virtual('formattedPhone').get(function() {
    if (!this.profile.phone) return '';
    const cleaned = this.profile.phone.replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
        return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    return this.profile.phone;
});

// Pre-save middleware to hash password
adminSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    
    try {
        const salt = await bcrypt.genSalt(12);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

// Pre-save middleware to format phone number
adminSchema.pre('save', function(next) {
    if (this.profile.phone) {
        this.profile.phone = this.profile.phone.replace(/\D/g, '');
    }
    next();
});

// Instance method to check password
adminSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

// Instance method to update last login
adminSchema.methods.updateLastLogin = function() {
    this.lastLogin = new Date();
    return this.save();
};

// Static method to create default super admin
adminSchema.statics.createDefaultAdmin = async function() {
    const existingAdmin = await this.findOne({ role: 'super_admin' });
    if (!existingAdmin) {
        const defaultAdmin = new this({
            name: 'Super Admin',
            email: 'admin@elderbloom.com',
            password: 'admin123',
            role: 'super_admin',
            permissions: {
                canViewContacts: true,
                canEditContacts: true,
                canViewSupportRequests: true,
                canEditSupportRequests: true,
                canAssignRequests: true,
                canViewAnalytics: true,
                canManageAdmins: true
            }
        });
        await defaultAdmin.save();
        console.log('Default super admin created: admin@elderbloom.com / admin123');
    }
};

// Static method to get admin statistics
adminSchema.statics.getStats = async function() {
    const total = await this.countDocuments();
    const active = await this.countDocuments({ isActive: true });
    const byRole = await this.aggregate([
        {
            $group: {
                _id: '$role',
                count: { $sum: 1 }
            }
        }
    ]);
    
    return {
        total,
        active,
        inactive: total - active,
        byRole: byRole.reduce((acc, role) => {
            acc[role._id] = role.count;
            return acc;
        }, {})
    };
};

module.exports = mongoose.model('Admin', adminSchema);
