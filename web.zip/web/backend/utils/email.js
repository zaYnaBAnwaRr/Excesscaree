const nodemailer = require('nodemailer');

// Create transporter
const createTransporter = () => {
    if (process.env.NODE_ENV === 'production') {
        // Production email configuration (e.g., SendGrid, AWS SES, etc.)
        return nodemailer.createTransporter({
            service: process.env.EMAIL_SERVICE || 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });
    } else {
        // Development email configuration (using Ethereal for testing)
        return nodemailer.createTransporter({
            host: 'smtp.ethereal.email',
            port: 587,
            auth: {
                user: 'ethereal.user@ethereal.email',
                pass: 'ethereal.pass'
            }
        });
    }
};

// Email templates
const templates = {
    'contact-notification': (data) => ({
        subject: 'New Contact Message - Elderbloom Support',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2c5aa0;">New Contact Message</h2>
                <p>A new contact message has been received through the Elderbloom Support website.</p>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #333; margin-top: 0;">Contact Details</h3>
                    <p><strong>Name:</strong> ${data.name}</p>
                    <p><strong>Email:</strong> ${data.email}</p>
                    <p><strong>Phone:</strong> ${data.phone || 'Not provided'}</p>
                    <p><strong>Message ID:</strong> ${data.contactId}</p>
                    <p><strong>Received:</strong> ${new Date(data.timestamp).toLocaleString()}</p>
                </div>
                
                <div style="background: #fff; border: 1px solid #ddd; padding: 20px; border-radius: 8px;">
                    <h3 style="color: #333; margin-top: 0;">Message</h3>
                    <p style="white-space: pre-wrap;">${data.message}</p>
                </div>
                
                <p style="margin-top: 20px;">
                    <a href="${process.env.ADMIN_PANEL_URL || 'http://localhost:5000/admin'}" 
                       style="background: #2c5aa0; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                        View in Admin Panel
                    </a>
                </p>
            </div>
        `
    }),
    
    'contact-auto-reply': (data) => ({
        subject: 'Thank you for contacting Elderbloom Support',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2c5aa0;">Thank You for Contacting Us</h2>
                <p>Dear ${data.name},</p>
                
                <p>Thank you for reaching out to Elderbloom Support. We have received your message and will get back to you within 24 hours.</p>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #333; margin-top: 0;">Your Message</h3>
                    <p style="white-space: pre-wrap;">${data.message}</p>
                </div>
                
                <p>In the meantime, if you have any urgent concerns, please don't hesitate to call us at <strong>+1 (555) 123-4567</strong>.</p>
                
                <p>Best regards,<br>The Elderbloom Support Team</p>
                
                <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
                <p style="font-size: 12px; color: #666;">
                    Elderbloom Support<br>
                    123 Care Street, Compassion City, CC 12345<br>
                    Phone: +1 (555) 123-4567<br>
                    Email: support@elderbloom.com
                </p>
            </div>
        `
    }),
    
    'support-notification': (data) => ({
        subject: `New Support Request - ${data.serviceType} - ${data.urgency} Priority`,
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2c5aa0;">New Support Request</h2>
                <p>A new support request has been submitted through the Elderbloom Support website.</p>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #333; margin-top: 0;">Request Details</h3>
                    <p><strong>Name:</strong> ${data.name}</p>
                    <p><strong>Email:</strong> ${data.email}</p>
                    <p><strong>Phone:</strong> ${data.phone}</p>
                    <p><strong>Service Type:</strong> ${data.serviceType}</p>
                    <p><strong>Urgency:</strong> <span style="color: ${data.urgency === 'emergency' ? '#e53e3e' : data.urgency === 'high' ? '#f56565' : '#4299e1'}; font-weight: bold;">${data.urgency.toUpperCase()}</span></p>
                    <p><strong>Request ID:</strong> ${data.requestId}</p>
                    <p><strong>Submitted:</strong> ${new Date(data.timestamp).toLocaleString()}</p>
                </div>
                
                ${data.message ? `
                <div style="background: #fff; border: 1px solid #ddd; padding: 20px; border-radius: 8px;">
                    <h3 style="color: #333; margin-top: 0;">Additional Details</h3>
                    <p style="white-space: pre-wrap;">${data.message}</p>
                </div>
                ` : ''}
                
                <p style="margin-top: 20px;">
                    <a href="${process.env.ADMIN_PANEL_URL || 'http://localhost:5000/admin'}" 
                       style="background: #2c5aa0; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                        View in Admin Panel
                    </a>
                </p>
            </div>
        `
    }),
    
    'support-confirmation': (data) => ({
        subject: 'Support Request Received - Elderbloom Support',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2c5aa0;">Support Request Confirmed</h2>
                <p>Dear ${data.name},</p>
                
                <p>Thank you for submitting your support request. We have received your request for <strong>${data.serviceType}</strong> and will contact you within 24 hours to discuss your needs.</p>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #333; margin-top: 0;">Request Summary</h3>
                    <p><strong>Service Type:</strong> ${data.serviceType}</p>
                    <p><strong>Priority Level:</strong> ${data.urgency}</p>
                    <p><strong>Request ID:</strong> ${data.requestId}</p>
                    <p><strong>Submitted:</strong> ${new Date().toLocaleString()}</p>
                </div>
                
                <p>Our team will review your request and contact you to:</p>
                <ul>
                    <li>Discuss your specific care needs</li>
                    <li>Schedule a free consultation</li>
                    <li>Create a personalized care plan</li>
                    <li>Match you with the right caregiver</li>
                </ul>
                
                <p>If you have any urgent concerns, please call us immediately at <strong>+1 (555) 123-4567</strong>.</p>
                
                <p>Best regards,<br>The Elderbloom Support Team</p>
                
                <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
                <p style="font-size: 12px; color: #666;">
                    Elderbloom Support<br>
                    123 Care Street, Compassion City, CC 12345<br>
                    Phone: +1 (555) 123-4567<br>
                    Email: support@elderbloom.com
                </p>
            </div>
        `
    })
};

// Send email function
const sendEmail = async ({ to, subject, template, data, html, text }) => {
    try {
        const transporter = createTransporter();
        
        let emailContent;
        if (template && templates[template]) {
            emailContent = templates[template](data);
        } else {
            emailContent = { subject, html, text };
        }
        
        const mailOptions = {
            from: process.env.EMAIL_FROM || 'noreply@elderbloom.com',
            to,
            subject: emailContent.subject || subject,
            html: emailContent.html || html,
            text: emailContent.text || text
        };
        
        const info = await transporter.sendMail(mailOptions);
        
        if (process.env.NODE_ENV === 'development') {
            console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
        }
        
        return info;
    } catch (error) {
        console.error('Email sending error:', error);
        throw error;
    }
};

module.exports = sendEmail;
