const express = require('express');
const router = express.Router();

// @route   GET /api/services
// @desc    Get all available services
// @access  Public
router.get('/', (req, res) => {
    const services = [
        {
            id: 'in-home',
            name: 'In-Home Care',
            description: 'Personalized care services in the comfort of your own home',
            icon: 'fas fa-home',
            features: [
                'Personal care assistance',
                'Medication management',
                'Meal preparation',
                'Light housekeeping',
                'Companionship',
                'Safety monitoring'
            ],
            pricing: {
                hourly: '$25-35/hour',
                daily: '$200-300/day',
                weekly: '$1200-1800/week'
            },
            availability: '24/7',
            coverage: 'Local area within 25 miles'
        },
        {
            id: 'medical',
            name: 'Medical Support',
            description: 'Professional medical assistance and health monitoring',
            icon: 'fas fa-user-md',
            features: [
                'Health assessments',
                'Medication reminders',
                'Doctor appointment coordination',
                'Emergency response',
                'Vital signs monitoring',
                'Medical equipment assistance'
            ],
            pricing: {
                hourly: '$30-45/hour',
                daily: '$250-350/day',
                weekly: '$1500-2200/week'
            },
            availability: '24/7 with on-call nurse',
            coverage: 'Local area within 30 miles'
        },
        {
            id: 'companionship',
            name: 'Companionship',
            description: 'Meaningful social interaction and emotional support',
            icon: 'fas fa-users',
            features: [
                'Social activities',
                'Conversation and companionship',
                'Hobby support',
                'Family communication',
                'Entertainment and games',
                'Emotional support'
            ],
            pricing: {
                hourly: '$20-30/hour',
                daily: '$150-250/day',
                weekly: '$900-1400/week'
            },
            availability: 'Flexible scheduling',
            coverage: 'Local area within 20 miles'
        },
        {
            id: 'transportation',
            name: 'Transportation',
            description: 'Safe and reliable transportation services',
            icon: 'fas fa-car',
            features: [
                'Medical appointments',
                'Shopping trips',
                'Social outings',
                'Emergency transport',
                'Wheelchair accessible vehicles',
                'Door-to-door service'
            ],
            pricing: {
                perTrip: '$15-25/trip',
                hourly: '$35-50/hour',
                monthly: '$200-400/month'
            },
            availability: '7 days a week, 6 AM - 10 PM',
            coverage: 'Local area within 50 miles'
        }
    ];

    res.json({
        success: true,
        data: services
    });
});

// @route   GET /api/services/:id
// @desc    Get a specific service by ID
// @access  Public
router.get('/:id', (req, res) => {
    const serviceId = req.params.id;
    
    const services = {
        'in-home': {
            id: 'in-home',
            name: 'In-Home Care',
            description: 'Personalized care services in the comfort of your own home',
            icon: 'fas fa-home',
            features: [
                'Personal care assistance',
                'Medication management',
                'Meal preparation',
                'Light housekeeping',
                'Companionship',
                'Safety monitoring'
            ],
            pricing: {
                hourly: '$25-35/hour',
                daily: '$200-300/day',
                weekly: '$1200-1800/week'
            },
            availability: '24/7',
            coverage: 'Local area within 25 miles',
            requirements: [
                'Initial assessment required',
                'Medical clearance if needed',
                'Emergency contact information',
                'Insurance information'
            ],
            process: [
                'Free consultation and assessment',
                'Customized care plan development',
                'Caregiver matching',
                'Regular monitoring and updates'
            ]
        },
        'medical': {
            id: 'medical',
            name: 'Medical Support',
            description: 'Professional medical assistance and health monitoring',
            icon: 'fas fa-user-md',
            features: [
                'Health assessments',
                'Medication reminders',
                'Doctor appointment coordination',
                'Emergency response',
                'Vital signs monitoring',
                'Medical equipment assistance'
            ],
            pricing: {
                hourly: '$30-45/hour',
                daily: '$250-350/day',
                weekly: '$1500-2200/week'
            },
            availability: '24/7 with on-call nurse',
            coverage: 'Local area within 30 miles',
            requirements: [
                'Medical history review',
                'Physician authorization',
                'Insurance verification',
                'Emergency contact information'
            ],
            process: [
                'Medical assessment by licensed nurse',
                'Care plan development with physician input',
                'Specialized caregiver assignment',
                'Regular health monitoring and reporting'
            ]
        },
        'companionship': {
            id: 'companionship',
            name: 'Companionship',
            description: 'Meaningful social interaction and emotional support',
            icon: 'fas fa-users',
            features: [
                'Social activities',
                'Conversation and companionship',
                'Hobby support',
                'Family communication',
                'Entertainment and games',
                'Emotional support'
            ],
            pricing: {
                hourly: '$20-30/hour',
                daily: '$150-250/day',
                weekly: '$900-1400/week'
            },
            availability: 'Flexible scheduling',
            coverage: 'Local area within 20 miles',
            requirements: [
                'Interest assessment',
                'Compatibility matching',
                'Background check clearance',
                'Emergency contact information'
            ],
            process: [
                'Companion matching based on interests',
                'Trial session to ensure compatibility',
                'Regular activity planning',
                'Progress monitoring and feedback'
            ]
        },
        'transportation': {
            id: 'transportation',
            name: 'Transportation',
            description: 'Safe and reliable transportation services',
            icon: 'fas fa-car',
            features: [
                'Medical appointments',
                'Shopping trips',
                'Social outings',
                'Emergency transport',
                'Wheelchair accessible vehicles',
                'Door-to-door service'
            ],
            pricing: {
                perTrip: '$15-25/trip',
                hourly: '$35-50/hour',
                monthly: '$200-400/month'
            },
            availability: '7 days a week, 6 AM - 10 PM',
            coverage: 'Local area within 50 miles',
            requirements: [
                'Mobility assessment',
                'Destination preferences',
                'Schedule coordination',
                'Emergency contact information'
            ],
            process: [
                'Transportation needs assessment',
                'Route planning and scheduling',
                'Driver assignment and training',
                'Regular service monitoring'
            ]
        }
    };

    const service = services[serviceId];
    
    if (!service) {
        return res.status(404).json({
            success: false,
            message: 'Service not found'
        });
    }

    res.json({
        success: true,
        data: service
    });
});

// @route   GET /api/services/:id/availability
// @desc    Check service availability
// @access  Public
router.get('/:id/availability', (req, res) => {
    const serviceId = req.params.id;
    const { date, time, duration } = req.query;

    // Mock availability check - in real app, this would query the database
    const availability = {
        available: true,
        slots: [
            { time: '09:00', available: true },
            { time: '10:00', available: true },
            { time: '11:00', available: false },
            { time: '12:00', available: true },
            { time: '13:00', available: true },
            { time: '14:00', available: true },
            { time: '15:00', available: false },
            { time: '16:00', available: true }
        ],
        nextAvailable: '2024-01-15T09:00:00Z',
        message: 'Service is available for the requested time slot'
    };

    res.json({
        success: true,
        data: availability
    });
});

// @route   GET /api/services/:id/pricing
// @desc    Get detailed pricing information for a service
// @access  Public
router.get('/:id/pricing', (req, res) => {
    const serviceId = req.params.id;
    const { duration, frequency } = req.query;

    // Mock pricing calculation - in real app, this would use actual pricing logic
    const pricing = {
        baseRate: 25,
        duration: duration || 'hourly',
        frequency: frequency || 'one-time',
        discounts: [
            {
                type: 'weekly',
                percentage: 10,
                description: '10% off for weekly bookings'
            },
            {
                type: 'monthly',
                percentage: 20,
                description: '20% off for monthly bookings'
            }
        ],
        additionalFees: [
            {
                type: 'weekend',
                amount: 5,
                description: 'Weekend surcharge'
            },
            {
                type: 'holiday',
                amount: 10,
                description: 'Holiday surcharge'
            }
        ],
        estimatedTotal: 25
    };

    res.json({
        success: true,
        data: pricing
    });
});

module.exports = router;
