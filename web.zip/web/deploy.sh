#!/bin/bash

# Elderbloom Support - Deployment Script for Hostinger VPS
# This script automates the deployment process

set -e  # Exit on any error

echo "🚀 Starting Elderbloom Support deployment..."

# Configuration
APP_NAME="elderbloom-support"
APP_DIR="/var/www/$APP_NAME"
BACKEND_DIR="$APP_DIR/backend"
FRONTEND_DIR="$APP_DIR/frontend"
SERVICE_NAME="elderbloom-api"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    print_error "Please do not run this script as root"
    exit 1
fi

# Check if required commands exist
check_requirements() {
    print_status "Checking requirements..."
    
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed. Please install Node.js 16+ first."
        exit 1
    fi
    
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    if ! command -v pm2 &> /dev/null; then
        print_warning "PM2 is not installed. Installing PM2..."
        npm install -g pm2
    fi
    
    if ! command -v mongod &> /dev/null; then
        print_warning "MongoDB is not installed. Please install MongoDB first."
        print_status "You can install MongoDB with: sudo apt install mongodb"
        exit 1
    fi
    
    print_status "All requirements satisfied!"
}

# Create application directory
setup_directories() {
    print_status "Setting up directories..."
    
    sudo mkdir -p $APP_DIR
    sudo chown -R $USER:$USER $APP_DIR
    
    print_status "Directories created successfully!"
}

# Install dependencies
install_dependencies() {
    print_status "Installing backend dependencies..."
    
    cd $BACKEND_DIR
    npm install --production
    
    print_status "Dependencies installed successfully!"
}

# Setup environment
setup_environment() {
    print_status "Setting up environment configuration..."
    
    if [ ! -f "$BACKEND_DIR/.env" ]; then
        cp $BACKEND_DIR/env.example $BACKEND_DIR/.env
        print_warning "Environment file created from example. Please edit $BACKEND_DIR/.env with your configuration."
    else
        print_status "Environment file already exists."
    fi
}

# Setup MongoDB
setup_mongodb() {
    print_status "Setting up MongoDB..."
    
    # Start MongoDB service
    sudo systemctl start mongodb
    sudo systemctl enable mongodb
    
    # Create database and initial admin user
    print_status "Creating initial admin user..."
    node -e "
    const mongoose = require('mongoose');
    const Admin = require('./models/Admin');
    
    async function createAdmin() {
        try {
            await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/elderbloom_support');
            await Admin.createDefaultAdmin();
            console.log('Default admin created successfully');
            process.exit(0);
        } catch (error) {
            console.error('Error creating admin:', error);
            process.exit(1);
        }
    }
    
    createAdmin();
    " || print_warning "Could not create default admin. Please create manually."
    
    print_status "MongoDB setup completed!"
}

# Setup PM2 process
setup_pm2() {
    print_status "Setting up PM2 process..."
    
    # Stop existing process if running
    pm2 stop $SERVICE_NAME 2>/dev/null || true
    pm2 delete $SERVICE_NAME 2>/dev/null || true
    
    # Start new process
    cd $BACKEND_DIR
    pm2 start server.js --name $SERVICE_NAME
    pm2 save
    pm2 startup
    
    print_status "PM2 process configured successfully!"
}

# Setup Nginx (optional)
setup_nginx() {
    if command -v nginx &> /dev/null; then
        print_status "Setting up Nginx configuration..."
        
        sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null <<EOF
server {
    listen 80;
    server_name _;
    
    # Frontend
    location / {
        root $FRONTEND_DIR;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }
    
    # API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Health check
    location /health {
        proxy_pass http://localhost:5000;
    }
}
EOF
        
        # Enable site
        sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
        sudo nginx -t && sudo systemctl reload nginx
        
        print_status "Nginx configuration completed!"
    else
        print_warning "Nginx not found. Skipping Nginx setup."
    fi
}

# Setup SSL (optional)
setup_ssl() {
    if command -v certbot &> /dev/null && [ ! -z "$DOMAIN_NAME" ]; then
        print_status "Setting up SSL certificate..."
        sudo certbot --nginx -d $DOMAIN_NAME --non-interactive --agree-tos --email admin@$DOMAIN_NAME
        print_status "SSL certificate configured!"
    else
        print_warning "Certbot not found or domain not specified. Skipping SSL setup."
    fi
}

# Main deployment function
deploy() {
    print_status "Starting deployment process..."
    
    check_requirements
    setup_directories
    install_dependencies
    setup_environment
    setup_mongodb
    setup_pm2
    setup_nginx
    
    if [ ! -z "$DOMAIN_NAME" ]; then
        setup_ssl
    fi
    
    print_status "Deployment completed successfully! 🎉"
    print_status "Your application is now running at: http://$(curl -s ifconfig.me)"
    print_status "API Health Check: http://$(curl -s ifconfig.me)/health"
    print_status ""
    print_status "Default admin credentials:"
    print_status "Email: admin@elderbloom.com"
    print_status "Password: admin123"
    print_warning "Please change the default password immediately!"
    print_status ""
    print_status "Useful commands:"
    print_status "  pm2 status              # Check application status"
    print_status "  pm2 logs $SERVICE_NAME  # View application logs"
    print_status "  pm2 restart $SERVICE_NAME # Restart application"
}

# Help function
show_help() {
    echo "Elderbloom Support Deployment Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -d, --domain DOMAIN    Set domain name for SSL setup"
    echo "  -h, --help            Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0                    # Deploy without SSL"
    echo "  $0 -d example.com     # Deploy with SSL for example.com"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -d|--domain)
            DOMAIN_NAME="$2"
            shift 2
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Run deployment
deploy
