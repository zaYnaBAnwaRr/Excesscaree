const express = require('express');
const { body, validationResult } = require('express-validator');
const SupportRequest = require('../models/SupportRequest');
const sendEmail = require('../utils/email');
const router = express.Router();

// Validation middleware
const supportValidation = [
    body('name')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters'),
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address'),
    body('phone')
        .isLength({ min: 10, max: 20 })
        .withMessage('Phone number must be between 10 and 20 characters'),
    body('serviceType')
        .isIn(['in-home', 'medical', 'companionship', 'transportation', 'other'])
        .withMessage('Invalid service type'),
    body('urgency')
        .optional()
        .isIn(['low', 'medium', 'high', 'emergency'])
        .withMessage('Invalid urgency level'),
    body('message')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Message cannot exceed 2000 characters')
];

// @route   POST /api/support
// @desc    Create a new support request
// @access  Public
router.post('/', supportValidation, async (req, res) => {
    try {
        // Check for validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { name, email, phone, serviceType, urgency, message } = req.body;

        // Create new support request
        const supportRequest = new SupportRequest({
            name,
            email,
            phone,
            serviceType,
            urgency: urgency || 'medium',
            message
        });

        await supportRequest.save();

        // Send notification email to admin
        try {
            await sendEmail({
                to: process.env.ADMIN_EMAIL || 'admin@elderbloom.com',
                subject: `New Support Request - ${supportRequest.serviceDisplayName} - ${urgency || 'Medium'} Priority`,
                template: 'support-notification',
                data: {
                    name,
                    email,
                    phone: supportRequest.formattedPhone,
                    serviceType: supportRequest.serviceDisplayName,
                    urgency: urgency || 'medium',
                    message,
                    requestId: supportRequest._id,
                    timestamp: supportRequest.createdAt
                }
            });
        } catch (emailError) {
            console.error('Email sending failed:', emailError);
            // Don't fail the request if email fails
        }

        // Send confirmation email to user
        try {
            await sendEmail({
                to: email,
                subject: 'Support Request Received - Elderbloom Support',
                template: 'support-confirmation',
                data: {
                    name,
                    serviceType: supportRequest.serviceDisplayName,
                    urgency: urgency || 'medium',
                    requestId: supportRequest._id,
                    message
                }
            });
        } catch (emailError) {
            console.error('Confirmation email failed:', emailError);
            // Don't fail the request if email fails
        }

        res.status(201).json({
            success: true,
            message: 'Your support request has been submitted successfully! We will contact you shortly.',
            data: {
                id: supportRequest._id,
                name: supportRequest.name,
                email: supportRequest.email,
                serviceType: supportRequest.serviceDisplayName,
                urgency: supportRequest.urgency,
                status: supportRequest.status
            }
        });

    } catch (error) {
        console.error('Support request creation error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to submit support request. Please try again later.'
        });
    }
});

// @route   GET /api/support
// @desc    Get all support requests (Admin only)
// @access  Private
router.get('/', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const status = req.query.status;
        const urgency = req.query.urgency;
        const serviceType = req.query.serviceType;
        const search = req.query.search;
        const sortBy = req.query.sortBy || 'createdAt';
        const sortOrder = req.query.sortOrder === 'asc' ? 1 : -1;

        // Build query
        const query = {};
        if (status) query.status = status;
        if (urgency) query.urgency = urgency;
        if (serviceType) query.serviceType = serviceType;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } },
                { message: { $regex: search, $options: 'i' } }
            ];
        }

        // Execute query with pagination
        const supportRequests = await SupportRequest.find(query)
            .populate('assignedTo', 'name email')
            .sort({ [sortBy]: sortOrder })
            .limit(limit * 1)
            .skip((page - 1) * limit)
            .select('-__v');

        const total = await SupportRequest.countDocuments(query);

        res.json({
            success: true,
            data: supportRequests,
            pagination: {
                current: page,
                pages: Math.ceil(total / limit),
                total,
                limit
            }
        });

    } catch (error) {
        console.error('Get support requests error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch support requests'
        });
    }
});

// @route   GET /api/support/stats
// @desc    Get support request statistics (Admin only)
// @access  Private
router.get('/stats', async (req, res) => {
    try {
        const stats = await SupportRequest.getStats();
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('Get support stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch support statistics'
        });
    }
});

// @route   GET /api/support/:id
// @desc    Get a specific support request (Admin only)
// @access  Private
router.get('/:id', async (req, res) => {
    try {
        const supportRequest = await SupportRequest.findById(req.params.id)
            .populate('assignedTo', 'name email')
            .populate('notes.addedBy', 'name email');

        if (!supportRequest) {
            return res.status(404).json({
                success: false,
                message: 'Support request not found'
            });
        }

        res.json({
            success: true,
            data: supportRequest
        });

    } catch (error) {
        console.error('Get support request error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch support request'
        });
    }
});

// @route   PUT /api/support/:id
// @desc    Update a support request (Admin only)
// @access  Private
router.put('/:id', async (req, res) => {
    try {
        const { 
            status, 
            priority, 
            assignedTo, 
            response, 
            estimatedStartDate, 
            estimatedDuration 
        } = req.body;

        const updateData = {};
        if (status) updateData.status = status;
        if (priority) updateData.priority = priority;
        if (assignedTo) updateData.assignedTo = assignedTo;
        if (response) {
            updateData.response = response;
            updateData.respondedAt = new Date();
        }
        if (estimatedStartDate) updateData.estimatedStartDate = estimatedStartDate;
        if (estimatedDuration) updateData.estimatedDuration = estimatedDuration;

        // Set completedAt if status is completed
        if (status === 'completed') {
            updateData.completedAt = new Date();
        }

        const supportRequest = await SupportRequest.findByIdAndUpdate(
            req.params.id,
            updateData,
            { new: true, runValidators: true }
        ).populate('assignedTo', 'name email');

        if (!supportRequest) {
            return res.status(404).json({
                success: false,
                message: 'Support request not found'
            });
        }

        res.json({
            success: true,
            message: 'Support request updated successfully',
            data: supportRequest
        });

    } catch (error) {
        console.error('Update support request error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update support request'
        });
    }
});

// @route   POST /api/support/:id/notes
// @desc    Add a note to a support request (Admin only)
// @access  Private
router.post('/:id/notes', async (req, res) => {
    try {
        const { note } = req.body;
        const adminId = req.user?.id || 'system'; // Assuming auth middleware sets req.user

        if (!note || note.trim().length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Note is required'
            });
        }

        const supportRequest = await SupportRequest.findById(req.params.id);
        if (!supportRequest) {
            return res.status(404).json({
                success: false,
                message: 'Support request not found'
            });
        }

        await supportRequest.addNote(note.trim(), adminId);

        res.json({
            success: true,
            message: 'Note added successfully'
        });

    } catch (error) {
        console.error('Add note error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to add note'
        });
    }
});

// @route   DELETE /api/support/:id
// @desc    Delete a support request (Admin only)
// @access  Private
router.delete('/:id', async (req, res) => {
    try {
        const supportRequest = await SupportRequest.findByIdAndDelete(req.params.id);

        if (!supportRequest) {
            return res.status(404).json({
                success: false,
                message: 'Support request not found'
            });
        }

        res.json({
            success: true,
            message: 'Support request deleted successfully'
        });

    } catch (error) {
        console.error('Delete support request error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete support request'
        });
    }
});

module.exports = router;
